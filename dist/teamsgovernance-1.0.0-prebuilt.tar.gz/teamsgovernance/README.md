# Teams Governance

Teams Governance adds an admin page that lists user-created Nextcloud Teams (formerly Circles).

## Usage


1. Enable the 'teamsgovernance' app.
2. Open **Administration settings**.
3. Click **Teams Governance** in the admin settings menu.

The page shows a paginated table with:

- Team name
- Creator
- Creation date
- Member count
- Per-team details panel with connected resources

Use the search box to filter by team name, creator display name, or creator username.

Use **View details** on a row to load connected Team resources on demand. The details panel includes:

- Team share (Files) yes/no indicator
- Connected resource count
- Provider breakdown (for example Talk, Deck, Files)
- Resource links and labels

If Teams/Circles data is unavailable, the page shows a clear status message instead of failing.

## Side loading in Nextcloud AIO

Use the steps below to install this app in your own Nextcloud AIO environment without publishing to the App Store.

### 1) Build frontend assets

From this app folder:

```bash
npm install
npm run build
```

### 2) Copy the app into AIO custom apps

Pick a location on your Docker host for custom apps (example: `/srv/nextcloud-custom-apps`).

Copy this app so the final path is:

`/srv/nextcloud-custom-apps/teamsgovernance`

### 3) Make sure Nextcloud can see that custom apps path

In AIO, mount your host custom-apps folder into the Nextcloud container as `/var/www/html/custom_apps`.

Then configure Nextcloud to use it (if not already configured):

```bash
docker exec -u www-data nextcloud-aio-nextcloud php occ config:system:set apps_paths 1 --value='{"path":"/var/www/html/custom_apps","url":"/custom_apps","writable":true}' --type=json
```

### 4) Enable the app

```bash
docker exec -u www-data nextcloud-aio-nextcloud php occ app:enable teamsgovernance
```

### 5) Open the page

- Sign in as admin.
- Go to **Administration settings**.
- Open **Teams Governance**.

### 6) Updating after code changes

After changes, rebuild and redeploy:

```bash
npm run build
docker exec -u www-data nextcloud-aio-nextcloud php occ app:disable teamsgovernance
docker exec -u www-data nextcloud-aio-nextcloud php occ app:enable teamsgovernance
```

Then hard refresh your browser (`Ctrl+F5`).

## Pre-built package for GitHub releases

You can publish a pre-built package so users do not need Node/npm.

### 1) Build assets

```bash
npm install
npm run build
```

### 2) Create release archive

From the parent directory of `teamsgovernance`:

```bash
tar -czf teamsgovernance-prebuilt.tar.gz teamsgovernance
```

This archive should include built assets in `js/` and `css/`.

### 3) Publish on GitHub

- Create a GitHub release tag (for example `v1.0.1`).
- Upload `teamsgovernance-prebuilt.tar.gz` as a release asset.
- Mention the supported Nextcloud versions in the release notes.

## Is side loading difficult? (UI upload vs filesystem)

Sideloading is usually straightforward, but the exact method depends on your deployment.

- In many Nextcloud setups, admins can use **Apps** → **Upload app** in the web UI.
- In containerized/AIO setups, administrators often use a mounted custom apps directory plus `occ app:enable`.

If you do not see **Upload app** in the UI, use the AIO/custom-apps method above. It is generally the most reliable approach for Docker-based environments.
